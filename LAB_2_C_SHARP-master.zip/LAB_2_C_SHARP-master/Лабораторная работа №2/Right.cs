﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Лабораторная_работа__2
{
    class Right : Triangle
    {
        public bool getSquareness()
        {
            if ((getSideAB() * getSideAB() + getSideBC() * getSideBC() == getSideAC() * getSideAC()) && getSideAB() > 0 && getSideBC() > 0 && getSideAC() > 0 || (getSideAB() * getSideAB() + getSideAC() * getSideAC() == getSideBC() * getSideBC()) && getSideAB() > 0 && getSideBC() > 0 && getSideAC() > 0 || (getSideAC() * getSideAC() + getSideBC() * getSideBC() == getSideAB() * getSideAB()) && getSideAB() > 0 && getSideBC() > 0 && getSideAC() > 0)
                return true;
            else
                return false;
        }
    }
}
